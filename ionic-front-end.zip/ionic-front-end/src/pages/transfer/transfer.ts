import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {UsersService} from "../../providers/users-service";
import {FormBuilder, FormGroup} from "@angular/forms";

/**
 * Generated class for the TransferPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-transfer',
  templateUrl: 'transfer.html',
})
export class TransferPage {
  private userList: Array<any>;
  private transferForm: FormGroup;

  constructor(public navCtrl: NavController, public navParams: NavParams, public usersService: UsersService, public formBuilder: FormBuilder) {

    this.transferForm = formBuilder.group({
      from: [''],
      to: [''],
      amount: [''],
    });
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TranferPage');
    this.usersService.getUsers().subscribe(users => {
      this.userList = users;
    })
  }

  onSubmit(value: any): void {
    if(this.transferForm.valid) {
      //this.usersService.transfer(value.from, value.to, value.amount)
      this.usersService.transfer(value.from, value.to, value.amount).subscribe(users => {
        this.userList = users;
      })
    }
  }



}
