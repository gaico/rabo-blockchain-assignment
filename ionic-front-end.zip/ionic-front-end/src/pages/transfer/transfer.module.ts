import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TransferPage } from './transfer';
import {UsersService} from "../../providers/users-service";

@NgModule({
  declarations: [
    TransferPage,
  ],
  imports: [
    IonicPageModule.forChild(TransferPage),
  ],
  providers:[
    UsersService
  ],
})
export class TransferPageModule {}
