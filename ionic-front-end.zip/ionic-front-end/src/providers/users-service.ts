import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class UsersService {
  public API = 'http://localhost:8080';

  constructor(public http: HttpClient) {
  }

  getUsers(): Observable<any> {
    return this.http.get(this.API + '/users');
  }

  transfer(from:string,to:string,amount:string): Observable<any>{
    return this.http.get(this.API.concat('/user/').concat(from.trim()).concat('/transfer?to=').concat(to.trim()).concat('&amount=').concat(amount.trim()).replace(/^\s+|\s+$/g,""));
  }
}
